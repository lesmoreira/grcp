using Grpc.Core;
using GrpcGreeter;

namespace GrpcGreeter.Services;

public class AccountService : Accounter.AccounterBase
{
    private readonly ILogger<AccountService> _logger;
    public AccountService(ILogger<AccountService> logger)
    {
        _logger = logger;
    }

    public override Task<StatusReply> Status(AccountRequest request, ServerCallContext context)
    {
        return Task.FromResult(new StatusReply
        {
            Message = "ACTIVE"
        });
    }
}
