var PROTO_PATH = __dirname + '/account.proto';

var grpc = require('@grpc/grpc-js');
var protoLoader = require('@grpc/proto-loader');
var packageDefinition = protoLoader.loadSync(
    PROTO_PATH,
    {keepCase: true,
     longs: String,
     enums: String,
     defaults: true,
     oneofs: true
    });
var proto = grpc.loadPackageDefinition(packageDefinition).account;

function main() {
  console.log(PROTO_PATH);
  var target = 'localhost:5299';
  var client = new proto.Accounter(target, grpc.credentials.createInsecure());
  
  var param = {Account: 123, Document: 123};
  client.Status(param, function(err, response) {
    console.log('Status:', response.message);
  });
}

main();